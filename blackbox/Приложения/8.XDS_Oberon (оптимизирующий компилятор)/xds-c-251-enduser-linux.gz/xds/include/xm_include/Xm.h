/* Xm.h  Oct 19  19:29:52  1996 */
/* Created using H2D v1.16 */
/* from module Xm.def and header Xm/Xm.h. */
/* Types which were created during translation */

/* Copyright (c) 1996 XDS Ltd, Russia. All rights reserved. 
 *
 * $RCSfile: Xm.h,v $ $Revision: 1.3 $ $Date: 1998/07/28 15:54:16 $
 */

#include <Xm/Xm.h>

#ifndef Xm_H_
#define Xm_H_

typedef XmSecondaryResourceData * PAXmSecondaryResourceData;

#endif  /* Xm_H_ */
