/* XDS v2.51: Copyright (c) 1999-2003 Excelsior, LLC. All Rights Reserved. */
#ifndef xrAReal_H_
#define xrAReal_H_
#include "X2C.h"

extern X2C_INT32 X2C_ENTIER(X2C_LONGREAL);

extern X2C_INT32 X2C_TRUNCI(X2C_LONGREAL, X2C_INT32, X2C_INT32);

extern X2C_CARD32 X2C_TRUNCC(X2C_LONGREAL, X2C_CARD32, X2C_CARD32);


#endif /* xrAReal_H_ */
