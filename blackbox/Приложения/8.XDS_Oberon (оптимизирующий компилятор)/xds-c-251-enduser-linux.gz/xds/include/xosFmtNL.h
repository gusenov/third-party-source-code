/* XDS v2.51: Copyright (c) 1999-2003 Excelsior, LLC. All Rights Reserved. */
#ifndef xosFmtNL_H_
#define xosFmtNL_H_
#include "X2C.h"

extern void X2C_StdOutN(void);


#endif /* xosFmtNL_H_ */
