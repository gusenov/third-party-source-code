#ifndef __XDS_Xauth_H
#define __XDS_Xauth_H

/* Copyright (c) 1996 XDS Ltd, Russia. All rights reserved. 
 *
 * $RCSfile: Xauth.h,v $ $Revision: 1.3 $ $Date/01/29 11:33:32 $
 */
#include <X11/Xauth.h>

typedef Xauth *PtrXauth;

#endif
