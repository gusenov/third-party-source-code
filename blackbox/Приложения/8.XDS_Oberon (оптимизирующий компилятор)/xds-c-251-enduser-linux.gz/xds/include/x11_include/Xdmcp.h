#ifndef __XDS_Xdmcp_H
#define __XDS_Xdmcp_H

/* Copyright (c) 1996 XDS Ltd, Russia. All rights reserved. 
 *
 * $RCSfile: Xdmcp.h,v $ $Revision: 1.3 $ $Date/01/29 11:33:32 $
 */
#include <X11/Xdmcp.h>

#endif
