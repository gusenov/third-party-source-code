#ifndef __XDS_DECkeysym_H
#define __XDS_DECkeysym_H

/* Copyright (c) 1996 XDS Ltd, Russia. All rights reserved. 
 *
 * $RCSfile: DECkeysym.h,v $ $Revision: 1.3 $ $Date: 1998/02/15 00:04:18 $
 */
#include <X11/DECkeysym.h>

#endif
