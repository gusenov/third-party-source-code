#ifndef __XDS_Xmd_H
#define __XDS_Xmd_H

/* Copyright (c) 1996 XDS Ltd, Russia. All rights reserved. 
 *
 * $RCSfile: Xmd.h,v $ $Revision: 1.3 $ $Date/01/29 11:33:32 $
 */
#include <X11/Xmd.h>

#endif
