#ifndef __XDS_Xatom_H
#define __XDS_Xatom_H

/* Copyright (c) 1996 XDS Ltd, Russia. All rights reserved. 
 *
 * $RCSfile: Xatom.h,v $ $Revision: 1.3 $ $Date: 1998/02/15 00:04:20 $
 */
#include <X11/Xatom.h>

#endif
