#ifndef __XDS_X_H
#define __XDS_X_H

/* Copyright (c) 1996 XDS Ltd, Russia. All rights reserved. 
 *
 * $RCSfile: X.h,v $ $Revision: 1.3 $ $Date: 1998/02/15 00:04:19 $
 */
#include <X11/X.h>

#define MAX_STUP_ARR (100000000)

#endif
