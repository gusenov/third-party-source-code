#ifndef __XDS_cursorfont_H
#define __XDS_cursorfont_H

/* Copyright (c) 1996 XDS Ltd, Russia. All rights reserved. 
 *
 * $RCSfile: cursorfont.h,v $ $Revision: 1.3 $ $Date/01/29 11:33:32 $
 */
#include <X11/cursorfont.h>

#endif
