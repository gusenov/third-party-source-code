#ifndef __XDS_X10_H
#define __XDS_X10_H

/* Copyright (c) 1996 XDS Ltd, Russia. All rights reserved. 
 *
 * $RCSfile: X10.h,v $ $Revision: 1.4 $ $Date: 1998/07/28 15:58:29 $
 */
#include <X11/X10.h>
#include "X.h"

typedef XAssoc 		*PtrXAssoc;
typedef XAssoc	 	*PAXAssoc;
typedef XAssocTable 	*PtrXAssocTable;

#endif
