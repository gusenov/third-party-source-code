#ifndef __XDS_Sunkeysym_H
#define __XDS_Sunkeysym_H

/* Copyright (c) 1996 XDS Ltd, Russia. All rights reserved. 
 *
 * $RCSfile: Sunkeysym.h,v $ $Revision: 1.3 $ $Date: 1998/02/15 00:04:19 $
 */
#include <X11/Sunkeysym.h>

#endif
