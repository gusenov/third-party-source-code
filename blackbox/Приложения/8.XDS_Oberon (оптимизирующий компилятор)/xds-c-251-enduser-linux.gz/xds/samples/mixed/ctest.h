extern void StrToUpper(char []);
