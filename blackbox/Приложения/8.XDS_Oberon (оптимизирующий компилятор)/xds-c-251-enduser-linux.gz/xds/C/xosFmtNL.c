/* XDS v2.51: Copyright (c) 1999-2003 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosFmtNL.c May 10 15:23:34 2005" */
#include "xosFmtNL.h"
#define xosFmtNL_C_
#include "xPOSIX.h"


extern void X2C_StdOutN(void)
{
   printf("\n");
} /* end X2C_StdOutN() */

