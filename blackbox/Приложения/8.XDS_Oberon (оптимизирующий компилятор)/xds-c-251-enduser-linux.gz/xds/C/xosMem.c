/* XDS v2.51: Copyright (c) 1999-2003 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosMem.c May 10 15:23:34 2005" */
#include "xosMem.h"
#define xosMem_C_
#include "xPOSIX.h"


extern X2C_ADDRESS X2C_AllocMem(X2C_CARD32 size)
{
   return malloc(size);
} /* end X2C_AllocMem() */


extern void X2C_InitMem(void)
{
} /* end X2C_InitMem() */


extern X2C_CARD32 X2C_GetAvailablePhysicalMemory(void)
{
   return X2C_max_longcard;
} /* end X2C_GetAvailablePhysicalMemory() */

