
/******************************************************************************/
/*                                                                            */
/*           Native code x86 run-time support for XDS Modula2/Oberon2         */
/*                                                                            */
/*           Compile by: wcc386 -ox -5s -zl -zld native.c                     */
/*                or by: sc -c -mx native.c                                   */
/*                                                                            */
/******************************************************************************/

int X2C_noMemoryException = 17;

