/* XDS v2.51: Copyright (c) 1999-2003 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosFmtIO.c May 10 15:23:34 2005" */
#include "xosFmtIO.h"
#define xosFmtIO_C_
#include "xrtsOS.h"

#define spaces "        "


static void outs(X2C_CHAR s[], X2C_CARD32 len)
{
   if (len==0ul) return;
   X2C_StdOut(s, len);
} /* end outs() */


extern void X2C_StdOutS(X2C_CHAR s[], X2C_CARD32 w)
{
   X2C_CARD32 l;
   l = 0ul;
   while (s[l]) ++l;
   outs(s, l);
   if (w>l) {
      while (w-l>8ul) {
         outs("        ", 8ul);
         l += 8ul;
      }
      if (w>l) outs("        ", w-l);
   }
} /* end X2C_StdOutS() */


extern void X2C_HexToStr(X2C_CHAR s[], X2C_CARD32 * pos, X2C_CARD32 no)
{
   X2C_CARD32 i;
   X2C_CARD32 d;
   *pos += 8ul;
   for (i = 0ul; i<=7ul; i++) {
      d = no&15ul;
      no = no/16ul;
      --*pos;
      if (d>9ul) s[*pos] = (X2C_CHAR)((65ul+d)-10ul);
      else s[*pos] = (X2C_CHAR)(48ul+d);
   } /* end for */
} /* end X2C_HexToStr() */


extern void X2C_StdOutH(X2C_CARD32 no, X2C_CARD32 w)
{
   X2C_CHAR buf[12];
   X2C_CARD32 pos;
   pos = 0ul;
   X2C_HexToStr(buf, &pos, no);
   if (w>8ul) {
      while (w>16ul) {
         outs("        ", 8ul);
         w -= 8ul;
      }
      if (w>8ul) outs("        ", w-8ul);
   }
   outs(buf, 8ul);
} /* end X2C_StdOutH() */


extern void X2C_DecToStr(X2C_CHAR s[], X2C_CARD32 * pos, X2C_CARD32 no)
{
   X2C_CARD32 i;
   X2C_CARD32 l;
   i = 1000000000ul;
   l = 10ul;
   while (i>no) {
      i = i/10ul;
      --l;
   }
   if (l==0ul) l = 1ul;
   *pos += l;
   i = *pos;
   while (l>0ul) {
      --i;
      s[i] = (X2C_CHAR)(48ul+no%10ul);
      no = no/10ul;
      --l;
   }
} /* end X2C_DecToStr() */


extern void X2C_StdOutD(X2C_CARD32 no, X2C_CARD32 w)
{
   X2C_CHAR buf[12];
   X2C_CARD32 pos;
   pos = 0ul;
   X2C_DecToStr(buf, &pos, no);
   if (w>pos) {
      while (w-pos>8ul) {
         outs("        ", 8ul);
         w -= 8ul;
      }
      if (w>pos) outs("        ", w-pos);
   }
   outs(buf, pos);
} /* end X2C_StdOutD() */

