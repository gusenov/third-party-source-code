/* XDS v2.51: Copyright (c) 1999-2003 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrExceptions.c May 10 15:23:34 2005" */
#include "xrExceptions.h"
#define xrExceptions_C_
#include "xmRTS.h"
#include "xPOSIX.h"
#include "xrsetjmp.h"
#include "X2C.h"
#include "xrtsOS.h"
#include "M2EXCEPTION.h"

#define st_normal 0

#define st_exceptional 1

#define st_off 2

#define st_reraise 3


extern void X2C_XInitHandler(X2C_XHandler x)
{
   X2C_Coroutine current;
   current = X2C_GetCurrent();
   x->state = 0;
   x->source = 0;
   x->next = current->handler;
   X2C_HIS_SAVE(&x->history);
   current->handler = x;
} /* end X2C_XInitHandler() */


extern void X2C_XOFF(void)
{
   X2C_Coroutine current;
   current = X2C_GetCurrent();
   current->handler->state = 2;
} /* end X2C_XOFF() */


extern void X2C_XON(void)
{
   X2C_Coroutine current;
   current = X2C_GetCurrent();
   current->handler->state = 3;
} /* end X2C_XON() */


extern void X2C_XRETRY(void)
{
   X2C_Coroutine current;
   X2C_XHandler x;
   current = X2C_GetCurrent();
   x = current->handler;
   x->state = 0;
   X2C_HIS_RESTORE(x->history);
   x->source = 0;
   longjmp(x->buf, 1);
} /* end X2C_XRETRY() */

static struct X2C_XSource_STR sysSourceRec;

static struct X2C_XSource_STR assertSourceRec;


extern void X2C_init_exceptions(void)
{
   struct X2C_XSource_STR * anonym;
   struct X2C_XSource_STR * anonym0;
   X2C_rtsSource = &sysSourceRec;
   { /* with */
      struct X2C_XSource_STR * anonym = X2C_rtsSource;
      anonym->number = 0ul;
      anonym->message[0u] = 0;
   }
   X2C_assertSrc = &assertSourceRec;
   { /* with */
      struct X2C_XSource_STR * anonym0 = X2C_assertSrc;
      anonym0->number = 0ul;
      anonym0->message[0u] = 0;
   }
} /* end X2C_init_exceptions() */


static void dectostr(X2C_CHAR s[], X2C_CARD32 s_len, X2C_CARD32 * pos,
                X2C_CARD32 no)
{
   X2C_CARD32 i;
   X2C_CARD32 l;
   X2C_CARD32 x;
   l = 0ul;
   x = no;
   while (x>0ul) {
      x = x/10ul;
      ++l;
   }
   if (l==0ul) l = 1ul;
   *pos += l;
   i = *pos;
   while (l>0ul) {
      --i;
      s[i] = (X2C_CHAR)(48ul+no%10ul);
      no = no/10ul;
      --l;
   }
} /* end dectostr() */


static void app0(X2C_CHAR d[], X2C_CARD32 d_len, X2C_CARD32 M,
                X2C_CARD32 * pos, X2C_CHAR s[], X2C_CARD32 s_len)
{
   X2C_CARD32 i;
   i = 0ul;
   while (*pos<M && s[i]) {
      d[*pos] = s[i];
      ++*pos;
      ++i;
   }
} /* end app() */


static void form_msg(X2C_Coroutine cur, X2C_XSource source)
{
   X2C_CARD32 pos;
   pos = 0ul;
   app0(cur->his_msg, 1024ul, 1024ul, &pos, "#RTS: unhandled exception #",
                28ul);
   X2C_DecToStr(cur->his_msg, &pos, source->number);
   if (source->message[0u]) {
      app0(cur->his_msg, 1024ul, 1024ul, &pos, ": ", 3ul);
      app0(cur->his_msg, 1024ul, 1024ul, &pos, source->message, 1024ul);
   }
   if (pos>=1024ul) pos = 1023ul;
   cur->his_msg[pos] = 0;
} /* end form_msg() */


static void doRaise(X2C_XSource source)
{
   X2C_XHandler x;
   X2C_Coroutine current;
   current = X2C_GetCurrent();
   x = current->handler;
   while (x && x->state) x = x->next;
   current->handler = x;
   if (x==0) {
      X2C_StdOut("\n#RTS: unhandled exception #", 28ul);
      X2C_StdOutD(source->number, 0ul);
      if (source->message[0u]) {
         X2C_StdOut(": ", 2ul);
         X2C_StdOut(source->message, X2C_LENGTH(source->message,1024ul));
      }
      X2C_StdOutN();
      form_msg(current, source);
      X2C_show_history();
      X2C_StdOutFlush();
      X2C_ABORT();
   }
   else {
      x->source = source;
      x->state = 1;
   }
   X2C_HIS_RESTORE(x->history);
   longjmp(x->buf, 2);
} /* end doRaise() */


extern void X2C_doRaise(X2C_XSource source)
{
   doRaise(source);
} /* end X2C_doRaise() */


extern void X2C_XREMOVE(void)
{
   X2C_XHandler x;
   X2C_XSource s;
   X2C_Coroutine current;
   current = X2C_GetCurrent();
   x = current->handler;
   if (x==0) X2C_TRAP_F((X2C_INT32)X2C_internalError);
   if ((X2C_INT32)x->state==3l) {
      s = x->source;
      current->handler = x->next;
      doRaise(s);
   }
   else current->handler = x->next;
} /* end X2C_XREMOVE() */


static void trap_message(X2C_CHAR msg[], X2C_CARD32 msg_len, X2C_CARD32 no)
{
   switch (no) {
   case 0ul:
      X2C_COPY("invalid index",14ul,msg,msg_len);
      break;
   case 1ul:
      X2C_COPY("expression out of bounds",25ul,msg,msg_len);
      break;
   case 2ul:
      X2C_COPY("invalid case in CASE statement",31ul,msg,msg_len);
      break;
   case 3ul:
      X2C_COPY("invalid location",17ul,msg,msg_len);
      break;
   case 4ul:
      X2C_COPY("function without RETURN statement",34ul,msg,msg_len);
      break;
   case 5ul:
      X2C_COPY("whole overflow",15ul,msg,msg_len);
      break;
   case 6ul:
      X2C_COPY("zero or negative divisor",25ul,msg,msg_len);
      break;
   case 7ul:
      X2C_COPY("real overflow",14ul,msg,msg_len);
      break;
   case 8ul:
      X2C_COPY("float division by zero",23ul,msg,msg_len);
      break;
   case 9ul:
      X2C_COPY("complex overflow",17ul,msg,msg_len);
      break;
   case 10ul:
      X2C_COPY("complex division by zero",25ul,msg,msg_len);
      break;
   case 11ul:
      X2C_COPY("protection error",17ul,msg,msg_len);
      break;
   case 12ul:
      X2C_COPY("SYSTEM exception",17ul,msg,msg_len);
      break;
   case 13ul:
      X2C_COPY("COROUTINE exception",20ul,msg,msg_len);
      break;
   case 14ul:
      X2C_COPY("EXCEPTIONS exception",21ul,msg,msg_len);
      break;
   default:;
      if (no==X2C_assertException) X2C_COPY("ASSERT",7ul,msg,msg_len);
      else if (no==X2C_guardException) {
         X2C_COPY("type guard check",17ul,msg,msg_len);
      }
      else if (no==X2C_noMemoryException) {
         X2C_COPY("out of heap space",18ul,msg,msg_len);
      }
      else if (no==X2C_unreachDLL) {
         X2C_COPY("call to unloaded DLL",21ul,msg,msg_len);
      }
      else if (no==X2C_internalError) {
         X2C_COPY("RTS internal error",19ul,msg,msg_len);
      }
      else if (no==X2C_castError) {
         X2C_COPY("invalid type cast",18ul,msg,msg_len);
      }
      else if (no==X2C_UserBreak) X2C_COPY("USER BREAK",11ul,msg,msg_len);
      else if (no==X2C_stack_overflow) {
         X2C_COPY("stack overflow",15ul,msg,msg_len);
      }
      else msg[0ul] = 0;
      break;
   } /* end switch */
} /* end trap_message() */


extern void X2C_TRAP_F(X2C_INT32 no)
{
   X2C_CARD32 pos;
   struct X2C_XSource_STR * anonym;
   trap_message(X2C_rtsSource->message, 1024ul, (X2C_CARD32)no);
   if (X2C_rtsSource->message[0u]==0) {
      { /* with */
         struct X2C_XSource_STR * anonym = X2C_rtsSource;
         X2C_COPY("TRAP(",6ul,anonym->message,1024u);
         pos = 5ul;
         dectostr(anonym->message, 1024ul, &pos, (X2C_CARD32)no);
         anonym->message[pos] = ')';
         anonym->message[pos+1ul] = 0;
      }
   }
   X2C_rtsSource->number = (X2C_CARD32)no;
   doRaise(X2C_rtsSource);
} /* end X2C_TRAP_F() */


extern void X2C_ASSERT_F(X2C_CARD32 no)
{
   X2C_CARD32 pos;
   struct X2C_XSource_STR * anonym;
   { /* with */
      struct X2C_XSource_STR * anonym = X2C_assertSrc;
      X2C_COPY("ASSERT(FALSE, ",15ul,anonym->message,1024u);
      pos = 14ul;
      dectostr(anonym->message, 1024ul, &pos, no);
      anonym->message[pos] = ')';
      anonym->message[pos+1ul] = 0;
      anonym->number = no;
   }
   doRaise(X2C_assertSrc);
} /* end X2C_ASSERT_F() */


static void app(X2C_CHAR d[], X2C_CARD32 M, X2C_CARD32 * pos, X2C_CHAR s[])
{
   X2C_CARD32 i;
   i = 0ul;
   while (*pos<M && s[i]) {
      d[*pos] = s[i];
      ++*pos;
      ++i;
   }
} /* end app() */


extern void X2C_ASSERT_FC(X2C_CARD32 code, X2C_pCHAR file, X2C_CARD32 line)
{
   X2C_CARD32 pos;
   X2C_CHAR ls[16];
   X2C_CHAR cs[16];
   pos = 0ul;
   dectostr(cs, 16ul, &pos, code);
   cs[pos] = 0;
   pos = 0ul;
   dectostr(ls, 16ul, &pos, line);
   ls[pos] = 0;
   pos = 0ul;
   app(X2C_assertSrc->message, 1023ul, &pos, "ASSERT(FALSE,");
   app(X2C_assertSrc->message, 1023ul, &pos, cs);
   app(X2C_assertSrc->message, 1023ul, &pos, ") at line ");
   app(X2C_assertSrc->message, 1023ul, &pos, ls);
   app(X2C_assertSrc->message, 1023ul, &pos, " of ");
   app(X2C_assertSrc->message, 1023ul, &pos, file);
   if (pos>=1024ul) pos = 1023ul;
   X2C_assertSrc->message[pos] = 0;
   X2C_assertSrc->number = code;
   doRaise(X2C_assertSrc);
} /* end X2C_ASSERT_FC() */

