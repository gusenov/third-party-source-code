/* XDS v2.51: Copyright (c) 1999-2003 Excelsior, LLC. All Rights Reserved. */
/* "@(#)XDSRTL.c May 10 15:23:34 2005" */
#include "XDSRTL.h"
#define XDSRTL_C_
#include "xmRTS.h"


extern void XDSRTL_Init(PINT argc, PPCHAR argv, X2C_INT32 gcauto,
                X2C_INT32 gcthreshold, X2C_INT32 heaplimit)
{
   X2C_BEGIN(argc, (X2C_ppCHAR)argv, gcauto, gcthreshold, heaplimit);
} /* end XDSRTL_Init() */


extern void XDSRTL_Exit(void)
{
   X2C_EXIT();
} /* end XDSRTL_Exit() */

