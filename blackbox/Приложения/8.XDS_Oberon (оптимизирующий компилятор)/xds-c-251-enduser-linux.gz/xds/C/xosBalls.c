/* XDS v2.51: Copyright (c) 1999-2003 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosBalls.c May 10 15:23:34 2005" */
#include "xosBalls.h"
#define xosBalls_C_
#include "xrtsOS.h"
#include "xrnMman.h"

#define hardPageSize 4096

static X2C_CARD32 bSize;

static X2C_ADDRESS heapBase;

static X2C_CARD32 numBlocks;


extern X2C_ADDRESS X2C_initBalls(X2C_CARD32 nBlocks, X2C_CARD32 blockSize)
{
   bSize = blockSize;
   heapBase = mmap(0, nBlocks*bSize, 0ul, 34ul, -1l, 0ul);
   return heapBase;
} /* end X2C_initBalls() */


extern X2C_ADDRESS X2C_allocBlock(X2C_ADDRESS adr)
{
   mprotect(adr, bSize, 3ul);
   return adr;
} /* end X2C_allocBlock() */


extern void X2C_freeBlock(X2C_ADDRESS adr)
{
   mprotect(adr, bSize, 0ul);
} /* end X2C_freeBlock() */


extern void X2C_freeAll(void)
{
   munmap(heapBase, numBlocks*bSize);
} /* end X2C_freeAll() */

