/* XDS v2.51: Copyright (c) 1999-2003 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosIpts.c May 10 15:23:34 2005" */
#include "xosIpts.h"
#define xosIpts_C_


extern void X2C_EnableIpts(void)
{
} /* end X2C_EnableIpts() */


extern void X2C_DisableIpts(void)
{
} /* end X2C_DisableIpts() */


extern void X2C_SaveIptHandler(X2C_CARD32 no)
{
} /* end X2C_SaveIptHandler() */


extern void X2C_RestoreIptHandler(X2C_CARD32 no)
{
} /* end X2C_RestoreIptHandler() */


extern X2C_BOOLEAN X2C_SetIptHandler(X2C_CARD32 no)
{
   return 0;
} /* end X2C_SetIptHandler() */

