/* XDS v2.51: Copyright (c) 1999-2003 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrcArythmetics.c May 10 15:23:34 2005" */
#include "xrcArythmetics.h"
#define xrcArythmetics_C_
#include "X2C.h"
#include "M2EXCEPTION.h"


extern X2C_INT32 X2C_REM_F(X2C_INT32 a, X2C_INT32 b)
{
   if (b==0l) X2C_TRAP(6l);
   if (a>=0l) {
      if (b>0l) return (a%b);
      else return (a%(-b));
   }
   else if (b>0l) return (-((-a)%b));
   else return (-(-a)%(-b));
   return 0l;
} /* end X2C_REM_F() */


extern X2C_INT32 X2C_QUO_F(X2C_INT32 a, X2C_INT32 b)
{
   if (b==0l) X2C_TRAP(6l);
   if (a>=0l) {
      if (b>0l) return (a/b);
      else return (-(a/(-b)));
   }
   else if (b>0l) return (-((-a)/b));
   else return ((-a)/(-b));
   return 0l;
} /* end X2C_QUO_F() */


extern X2C_INT32 X2C_MOD_F(X2C_INT32 a, X2C_INT32 b)
{
   X2C_INT32 c;
   if (b<=0l) X2C_TRAP(6l);
   c = (a % b);
   if (a<0l && c<0l) c += b;
   return c;
} /* end X2C_MOD_F() */


extern X2C_INT32 X2C_DIV_F(X2C_INT32 a, X2C_INT32 b)
{
   X2C_INT32 c;
   if (b<=0l) X2C_TRAP(6l);
   c = (a/b);
   if (a<0l && c*b>a) --c;
   return c;
} /* end X2C_DIV_F() */


extern X2C_REAL X2C_DIVR_F(X2C_REAL a, X2C_REAL b)
{
   if (b==0.0f) X2C_TRAP(8l);
   else return (a/b);
   return 0.0f;
} /* end X2C_DIVR_F() */


extern X2C_LONGREAL X2C_DIVL_F(X2C_LONGREAL a, X2C_LONGREAL b)
{
   if (b==0.0) X2C_TRAP(8l);
   else return (a/b);
   return 0.0;
} /* end X2C_DIVL_F() */


extern X2C_INT8 X2C_ABS_INT8(X2C_INT8 x)
{
   if ((X2C_INT32)x>=0l) return x;
   if ((X2C_INT32)x==-128l) X2C_TRAP(1l);
   return -x;
} /* end X2C_ABS_INT8() */


extern X2C_INT16 X2C_ABS_INT16(X2C_INT16 x)
{
   if ((X2C_INT32)x>=0l) return x;
   if ((X2C_INT32)x==-32768l) X2C_TRAP(1l);
   return -x;
} /* end X2C_ABS_INT16() */


extern X2C_INT32 X2C_ABS_INT32(X2C_INT32 x)
{
   if (x>=0l) return x;
   if (x==X2C_min_longint) X2C_TRAP(1l);
   return -x;
} /* end X2C_ABS_INT32() */

