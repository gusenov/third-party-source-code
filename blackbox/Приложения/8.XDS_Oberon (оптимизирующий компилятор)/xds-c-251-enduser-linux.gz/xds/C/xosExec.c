/* XDS v2.51: Copyright (c) 1999-2003 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosExec.c May 10 15:23:34 2005" */
#include "xosExec.h"
#define xosExec_C_
#include "xmRTS.h"
#include "xPOSIX.h"
#include "xlibOS.h"
#include "X2C.h"


extern X2C_INT32 X2C_Execute(X2C_pCHAR cmd, X2C_pCHAR args, int overlay,
                X2C_CARD32 * exitcode)
{
   xPOSIX_PCHAR argv[256];
   X2C_INT32 i;
   X2C_INT32 rc;
   i = 1l;
   for (;;) {
      while ((X2C_CARD8)(*args)<=' ') {
         if (*args==0) goto loop_exit;
         args = (X2C_pCHAR)(X2C_ADDRESS)((X2C_ADDRESS)(X2C_ADDRESS)
                args+(X2C_INT32)1ul);
      }
      argv[i] = (xPOSIX_PCHAR)args;
      ++i;
      while ((X2C_CARD8)(*args)>' ') {
         args = (X2C_pCHAR)(X2C_ADDRESS)((X2C_ADDRESS)(X2C_ADDRESS)
                args+(X2C_INT32)1ul);
      }
      if (*args==0) break;
      *args = 0;
      args = (X2C_pCHAR)(X2C_ADDRESS)((X2C_ADDRESS)(X2C_ADDRESS)
                args+(X2C_INT32)1ul);
   }
   loop_exit:;
   argv[i] = 0;
   argv[0u] = (xPOSIX_PCHAR)cmd;
   if (overlay) {
      #if defined(_msdos)
      rc = spawnv(P_WAIT, cmd, argv);
      #else
      rc = execv(cmd, argv);
      #endif
   }
   else rc = spawnv(P_WAIT, cmd, argv);
   if (rc<0l) return errno;
   else {
      *exitcode = (X2C_CARD32)rc;
      return 0l;
   }
   return 0;
} /* end X2C_Execute() */


extern X2C_INT32 X2C_Command(X2C_pCHAR cmd, X2C_CARD32 * exitcode)
{
   X2C_INT32 rc;
   rc = system(cmd);
   if (rc<0l) return errno;
   else {
      *exitcode = (X2C_CARD32)rc;
      return 0l;
   }
   return 0;
} /* end X2C_Command() */

