/* XDS v2.51: Copyright (c) 1999-2003 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosTimeOps.c May 10 15:23:34 2005" */
#include "xosTimeOps.h"
#define xosTimeOps_C_
#include "xlibOS.h"

#define y001days 365

#define y004days 1461

#define y100days 36524

#define y400days 146097

static X2C_CARD32 monthAdd[12] = {0ul,3ul,3ul,6ul,8ul,11ul,13ul,16ul,19ul,
                21ul,24ul,26ul};

static X2C_CARD32 monthLast[12] = {31ul,59ul,90ul,120ul,151ul,181ul,212ul,
                243ul,273ul,304ul,334ul,365ul};

#define FirstValidYear 1

static struct X2C_TimeStruct FirstDate = {1ul,1ul,1ul,0ul,0ul,0ul,0ul,0l,0};


static X2C_BOOLEAN is_leap(X2C_CARD32 y)
{
   return (y&3ul)==0ul && y%100ul || y%400ul==0ul;
} /* end is_leap() */

static X2C_CARD32 xosTimeOps_m30days = 0xA50ul;


static X2C_BOOLEAN is_valid_day(X2C_CARD32 y, X2C_CARD32 m, X2C_CARD32 d)
{
   if (d<1ul || d>31ul) return 0;
   if (m<1ul || m>12ul) return 0;
   if (y<1ul) return 0;
   if (X2C_IN(m,32,0xA50ul) && d>30ul) return 0;
   if (m==2ul && d>28ul+(X2C_CARD32)is_leap(y)) return 0;
   return 1;
} /* end is_valid_day() */

static X2C_CARD32 xosTimeOps_m30days0 = 0xA50ul;


static X2C_BOOLEAN is_valid(struct X2C_TimeStruct d)
{
   if (is_valid_day(d.year, d.month, d.day)) {
      if ((d.hour>23ul || d.min0>59ul) || d.sec>59ul) return 0;
      return 1;
   }
   return 0;
} /* end is_valid() */

static X2C_CARD32 _cnst0[12] = {0ul,3ul,3ul,6ul,8ul,11ul,13ul,16ul,19ul,21ul,
                24ul,26ul};

static X2C_CARD32 day_of_year(X2C_CARD32 y, X2C_CARD32 m, X2C_CARD32 d)
{
   X2C_CARD32 x;
   --m;
   x = d+m*28ul+_cnst0[m];
   if (m>=2ul && is_leap(y)) ++x;
   return x;
} /* end day_of_year() */


static X2C_CARD32 the_day(X2C_CARD32 y, X2C_CARD32 m, X2C_CARD32 d)
{
   X2C_CARD32 year;
   X2C_CARD32 day;
   year = y;
   --y;
   day = (y/400ul)*146097ul;
   y = y%400ul;
   day += (y/100ul)*36524ul;
   y = y%100ul;
   day += (y/4ul)*1461ul;
   day += (y&3ul)*365ul;
   day += day_of_year(year, m, d);
   return day;
} /* end the_day() */


extern X2C_CARD32 X2C_TimeDayNum(X2C_CARD32 y, X2C_CARD32 m, X2C_CARD32 d)
{
   if (is_valid_day(y, m, d)) return the_day(y, m, d);
   return 0ul;
} /* end X2C_TimeDayNum() */


static X2C_CARD32 sub_days(struct X2C_TimeStruct g, struct X2C_TimeStruct l)
{
   X2C_CARD32 c;
   c = ((l.year-1ul)/400ul)*400ul;
   g.year = g.year-c;
   l.year = l.year-c;
   return the_day(g.year, g.month, g.day)-the_day(l.year, l.month, l.day);
} /* end sub_days() */


static X2C_CARD32 day_sec(X2C_CARD32 h, X2C_CARD32 m, X2C_CARD32 s)
{
   return s+m*60ul+h*3600ul;
} /* end day_sec() */


static X2C_CARD32 sub_secs(struct X2C_TimeStruct g, struct X2C_TimeStruct l)
{
   X2C_CARD32 days;
   days = sub_days(g, l);
   return (days*86400ul+day_sec(g.hour, g.min0, g.sec))-day_sec(l.hour,
                l.min0, l.sec);
} /* end sub_secs() */

static X2C_CARD32 _cnst1[12] = {31ul,59ul,90ul,120ul,151ul,181ul,212ul,243ul,
                273ul,304ul,334ul,365ul};

static void unpack_day(X2C_CARD32 day, X2C_CARD32 * y, X2C_CARD32 * m,
                X2C_CARD32 * d)
{
   X2C_CARD32 i;
   X2C_BOOLEAN leap;
   --day;
   *y = 400ul*(day/146097ul);
   day = day%146097ul;
   i = day/36524ul;
   if (i==4ul) i = 3ul;
   *y += i*100ul;
   day -= i*36524ul;
   i = day/1461ul;
   day -= i*1461ul;
   *y += i*4ul;
   i = day/365ul;
   if (i==4ul) i = 3ul;
   *y += i;
   day -= i*365ul;
   leap = is_leap(*y+1ul);
   ++day;
   *m = day/32ul;
   day -= (X2C_CARD32)(leap && day>31ul);
   while (*m<=11ul && day>_cnst1[*m]) ++*m;
   *d = day;
   if (*m>0ul) *d -= _cnst1[*m-1ul];
   ++*m;
   *d += (X2C_CARD32)(leap && *m==2ul);
} /* end unpack_day() */


static void add_days(X2C_CARD32 * y, X2C_CARD32 * m, X2C_CARD32 * d,
                X2C_CARD32 days)
{
   X2C_CARD32 cy400s;
   cy400s = (*y-1ul)/400ul;
   *y -= cy400s*400ul;
   cy400s += days/146097ul;
   days = days%146097ul;
   unpack_day(days+the_day(*y, *m, *d), y, m, d);
   *y = *y+cy400s*400ul+1ul;
} /* end add_days() */


static void add_secs(X2C_CARD32 * y, X2C_CARD32 * m, X2C_CARD32 * d,
                X2C_CARD32 * h, X2C_CARD32 * mi, X2C_CARD32 * s,
                X2C_CARD32 secs)
{
   X2C_CARD32 days;
   secs += day_sec(*h, *mi, *s);
   days = secs/86400ul;
   secs = secs%86400ul;
   add_days(y, m, d, days);
   *h = secs/3600ul;
   secs = secs%3600ul;
   *mi = secs/60ul;
   *s = secs%60ul;
} /* end add_secs() */


extern X2C_INT32 X2C_TimeCompare(struct X2C_TimeStruct dl,
                struct X2C_TimeStruct dr)
{
   X2C_INT32 r;
   if (!(is_valid(dl) && is_valid(dr))) return 0l;
   r = (X2C_INT32)dl.year-(X2C_INT32)dr.year;
   if (r) return r;
   r = (X2C_INT32)dl.month-(X2C_INT32)dr.month;
   if (r) return r;
   r = (X2C_INT32)dl.day-(X2C_INT32)dr.day;
   if (r) return r;
   r = (X2C_INT32)dl.hour-(X2C_INT32)dr.hour;
   if (r) return r;
   r = (X2C_INT32)dl.min0-(X2C_INT32)dr.min0;
   if (r) return r;
   r = (X2C_INT32)dl.sec-(X2C_INT32)dr.sec;
   if (r) return r;
   return (X2C_INT32)dl.fracs-(X2C_INT32)dr.fracs;
} /* end X2C_TimeCompare() */


extern X2C_CARD32 X2C_TimeDayInt(struct X2C_TimeStruct dl,
                struct X2C_TimeStruct dr)
{
   if (!(is_valid(dl) && is_valid(dr))) return 0ul;
   if (X2C_TimeCompare(dl, dr)<=0l) return 0ul;
   return sub_days(dl, dr);
} /* end X2C_TimeDayInt() */


extern X2C_CARD32 X2C_TimeSecInt(struct X2C_TimeStruct dl,
                struct X2C_TimeStruct dr)
{
   if (!(is_valid(dl) && is_valid(dr))) return 0ul;
   if (X2C_TimeCompare(dl, dr)<=0l) return 0ul;
   return sub_secs(dl, dr);
} /* end X2C_TimeSecInt() */

static struct X2C_TimeStruct _cnst = {1ul,1ul,1ul,0ul,0ul,0ul,0ul,0l,0};

extern void X2C_TimeDayAdd(struct X2C_TimeStruct D, X2C_CARD32 days,
                struct X2C_TimeStruct * res)
{
   X2C_CARD32 d;
   X2C_CARD32 m;
   X2C_CARD32 y;
   *res = _cnst;
   if (!is_valid(D)) return;
   y = D.year;
   m = D.month;
   d = D.day;
   add_days(&y, &m, &d, days);
   *res = D;
   res->year = y;
   res->month = m;
   res->day = d;
} /* end X2C_TimeDayAdd() */


extern void X2C_TimeSecAdd(struct X2C_TimeStruct D, X2C_CARD32 secs,
                struct X2C_TimeStruct * res)
{
   X2C_CARD32 s;
   X2C_CARD32 mi;
   X2C_CARD32 h;
   X2C_CARD32 d;
   X2C_CARD32 m;
   X2C_CARD32 y;
   *res = _cnst;
   if (!is_valid(D)) return;
   y = D.year;
   m = D.month;
   d = D.day;
   h = D.hour;
   mi = D.min0;
   s = D.sec;
   add_secs(&y, &m, &d, &h, &mi, &s, secs);
   res->year = y;
   res->month = m;
   res->day = d;
   res->hour = h;
   res->min0 = mi;
   res->sec = s;
   res->fracs = D.fracs;
   res->zone = D.zone;
   res->stf = D.stf;
} /* end X2C_TimeSecAdd() */

