/* XDS v2.51: Copyright (c) 1999-2003 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrSETs.c May 10 15:23:34 2005" */
#include "xrSETs.h"
#define xrSETs_C_


extern X2C_INT32 X2C_ASH(X2C_INT32 a, X2C_INT32 b)
{
   return (b >= 0) ? (a << b) : (a >> (-b));
   return 0l;
} /* end X2C_ASH() */


extern X2C_CARD32 X2C_ROT(X2C_CARD32 a, X2C_INT16 length, X2C_INT32 n)
{
   X2C_CARD32 m;
   m = 0ul;
   m = (length==32) ? 0xFFFFFFFFl : (1l << length)-1;
   if (n>0l) {
      n=n % length;
      return ((a << n) | (a >> (length - n))) & m;
   }
   else {
      n= -n % length;
      return ((a >> n) | (a << (length - n))) & m;
   }
   return 0ul;
} /* end X2C_ROT() */


extern X2C_CARD32 X2C_LSH(X2C_CARD32 a, X2C_INT16 length, X2C_INT32 n)
{
   X2C_CARD32 m;
   m = 0ul;
   m = (length==32) ? 0xFFFFFFFFl : (1l << length)-1;
   if (n>0l) {
      if (n>=(X2C_INT32)length) return 0ul;
      return (a << n) & m;
   }
   else {
      if (n<=(X2C_INT32) -length) return 0ul;
      return (a >> -n) & m;
   }
   return 0ul;
} /* end X2C_LSH() */

